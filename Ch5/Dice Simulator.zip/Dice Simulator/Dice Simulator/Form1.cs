﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dice_Simulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void RollButton_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            int index_1 = rand.Next(FirstDiceimageList.Images.Count);

            int index_2 = rand.Next(SecondDiceimageList.Images.Count);

            FirstPictureBox.Image = FirstDiceimageList.Images[index_1];
            SecondPictureBox.Image = SecondDiceimageList.Images[index_2];
            
        }
    }
}
