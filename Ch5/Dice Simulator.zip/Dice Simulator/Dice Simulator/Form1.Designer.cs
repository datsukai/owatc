﻿namespace Dice_Simulator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.RollButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.FirstDiceimageList = new System.Windows.Forms.ImageList(this.components);
            this.SecondDiceimageList = new System.Windows.Forms.ImageList(this.components);
            this.FirstPictureBox = new System.Windows.Forms.PictureBox();
            this.SecondPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.FirstPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SecondPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // RollButton
            // 
            this.RollButton.Location = new System.Drawing.Point(57, 214);
            this.RollButton.Name = "RollButton";
            this.RollButton.Size = new System.Drawing.Size(111, 35);
            this.RollButton.TabIndex = 2;
            this.RollButton.Text = "Roll Dice";
            this.RollButton.UseVisualStyleBackColor = true;
            this.RollButton.Click += new System.EventHandler(this.RollButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(204, 214);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(111, 35);
            this.ExitButton.TabIndex = 3;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // FirstDiceimageList
            // 
            this.FirstDiceimageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("FirstDiceimageList.ImageStream")));
            this.FirstDiceimageList.TransparentColor = System.Drawing.Color.Transparent;
            this.FirstDiceimageList.Images.SetKeyName(0, "Die1.bmp");
            this.FirstDiceimageList.Images.SetKeyName(1, "Die2.bmp");
            this.FirstDiceimageList.Images.SetKeyName(2, "Die3.bmp");
            this.FirstDiceimageList.Images.SetKeyName(3, "Die4.bmp");
            this.FirstDiceimageList.Images.SetKeyName(4, "Die5.bmp");
            this.FirstDiceimageList.Images.SetKeyName(5, "Die6.bmp");
            // 
            // SecondDiceimageList
            // 
            this.SecondDiceimageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("SecondDiceimageList.ImageStream")));
            this.SecondDiceimageList.TransparentColor = System.Drawing.Color.Transparent;
            this.SecondDiceimageList.Images.SetKeyName(0, "Die1.bmp");
            this.SecondDiceimageList.Images.SetKeyName(1, "Die2.bmp");
            this.SecondDiceimageList.Images.SetKeyName(2, "Die3.bmp");
            this.SecondDiceimageList.Images.SetKeyName(3, "Die4.bmp");
            this.SecondDiceimageList.Images.SetKeyName(4, "Die5.bmp");
            this.SecondDiceimageList.Images.SetKeyName(5, "Die6.bmp");
            // 
            // FirstPictureBox
            // 
            this.FirstPictureBox.Location = new System.Drawing.Point(39, 32);
            this.FirstPictureBox.Name = "FirstPictureBox";
            this.FirstPictureBox.Size = new System.Drawing.Size(143, 130);
            this.FirstPictureBox.TabIndex = 4;
            this.FirstPictureBox.TabStop = false;
            // 
            // SecondPictureBox
            // 
            this.SecondPictureBox.Location = new System.Drawing.Point(204, 32);
            this.SecondPictureBox.Name = "SecondPictureBox";
            this.SecondPictureBox.Size = new System.Drawing.Size(143, 130);
            this.SecondPictureBox.TabIndex = 5;
            this.SecondPictureBox.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(394, 272);
            this.Controls.Add(this.SecondPictureBox);
            this.Controls.Add(this.FirstPictureBox);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.RollButton);
            this.Name = "Form1";
            this.Text = "Dice Simulator";
            ((System.ComponentModel.ISupportInitialize)(this.FirstPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SecondPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button RollButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.ImageList FirstDiceimageList;
        private System.Windows.Forms.ImageList SecondDiceimageList;
        private System.Windows.Forms.PictureBox FirstPictureBox;
        private System.Windows.Forms.PictureBox SecondPictureBox;
    }
}

